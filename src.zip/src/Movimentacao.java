public class Movimentacao {
        int x, y;
        String emoji;

        public Movimentacao(int x, int y, String emoji) {
            this.x = x;
            this.y = y;
            this.emoji = emoji;
    }
}
